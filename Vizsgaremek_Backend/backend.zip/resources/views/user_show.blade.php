<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show</title>
</head>
<body>
    <div class="container">
        <h1>User</h1>
        <p>{{$user -> name}}</p>
        <p>{{$post -> email}}</p>
    </div>
</body>
</html>