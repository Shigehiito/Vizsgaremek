<template>
  <div class="thread-container">
    <h1>All Threads</h1>

    <div class="create-post">
      <h2>Create a New Thread</h2>
      <form @submit.prevent="createPost">
      <input v-model="newTitle" type="text" placeholder="Thread Title" required />
      <textarea v-model="newContent" placeholder="Thread Content" required></textarea>
      
      <!-- 🔥 NEW CATEGORY DROPDOWN -->
      <select v-model="selectedCategory" required>
        <option disabled value="">Select Category</option>
        <option v-for="category in categories" :key="category.id" :value="category.id">
          {{ category.id }}
        </option>
      </select>

      <button type="submit">Create Thread</button>
    </form>
    </div>

    <div v-for="post in posts" :key="post.id" class="post">
      <h3>{{ post.title }}</h3>
      <p>{{ post.body }}</p>
      <p><strong>Author:</strong> {{ post.user_name }}</p>

      <button 
        v-if="post.user_id == currentUserId"
        @click="deletePost(post.id)"
        class="delete-button"
      >
        Delete
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'

const posts = ref([])
const newTitle = ref('')
const newContent = ref('')
const selectedCategory = ref('') // 🆕 category selected from dropdown
const currentUserId = ref(localStorage.getItem('user_id') || '') // ✅ fix here

const categories = ref([
  { id: 1, name: 'Elden Ring' },
  { id: 2, name: 'Grand Theft Auto V' },
  { id: 3, name: 'Warframe' },
  { id: 4, name: 'League Of Legends' },
  { id: 5, name: 'Counter-Strike 2' },
  { id: 6, name: 'Minecraft' },
  { id: 7, name: 'Path of Exile 2' },
  { id: 8, name: 'Pokemon Legends Z-A' },
  { id: 9, name: 'The First Berserker: Khazan' },
  { id: 10, name: 'Assassin\'s Creed Shadows' },
])

const fetchPosts = async () => {
  try {
    const response = await fetch('http://127.0.0.1:8000/api/posts')
    const data = await response.json()
    posts.value = data
  } catch (error) {
    console.error('Error fetching posts:', error)
  }
}

const createPost = async () => {
  if (!currentUserId.value) {
    alert('You must be logged in to create a thread!');
    return;
  }

  try {
    const response = await fetch('http://127.0.0.1:8000/api/posts', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify({
        title: newTitle.value,
        body: newContent.value,
        user_id: currentUserId.value,
        category_id: selectedCategory.value,
      }),
    });

    const result = await response.json().catch(() => ({}));

    if (response.ok) {
      alert('Thread created successfully!');
      newTitle.value = '';
      newContent.value = '';
      fetchPosts();
    } else {
      console.error('Backend error:', result);
      alert(result.message || 'Failed to create thread.');
    }
  } catch (error) {
    console.error('Network error:', error);
    alert('Create thread failed. Please try again.');
  }
}

onMounted(fetchPosts)

</script>

<style scoped>
.thread-container {
  max-width: 700px;
  margin: 2rem auto;
  padding: 1rem;
}
.create-post {
  margin-bottom: 2rem;
  padding: 1rem;
  border: 1px solid #ccc;
  border-radius: 8px;
}
.create-post form {
  margin-top: 1rem;
}
.create-post input,
.create-post textarea {
  display: block;
  width: 100%;
  padding: 0.5rem;
  margin-bottom: 1rem;
  border: 1px solid #aaa;
  border-radius: 4px;
}
.create-post button {
  width: 100%;
  padding: 0.75rem;
  border: none;
  background-color: rgb(1, 119, 17);
  color: white;
  border-radius: 4px;
  cursor: pointer;
}
.post {
  margin-bottom: 1rem;
  padding: 1rem;
  border: 1px solid #ccc;
  border-radius: 8px;
}
.delete-button {
  margin-top: 0.5rem;
  padding: 0.5rem;
  background-color: #d9534f;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
.delete-button:hover {
  background-color: #c9302c;
}
</style>
